package com.hadoop;

public class ErrorTO {
	String tweet;
    String tweetedOn;
    String tweetedBy;
    
    
	public String getTweet() {
		return tweet;
	}
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	public String getTweetedOn() {
		return tweetedOn;
	}
	public void setTweetedOn(String tweetedOn) {
		this.tweetedOn = tweetedOn;
	}
	public String getTweetedBy() {
		return tweetedBy;
	}
	public void setTweetedBy(String tweetedBy) {
		this.tweetedBy = tweetedBy;
	}
    
}
